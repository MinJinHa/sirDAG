one.BCDonG <-
function(k,l,gMat,B,datX,datY,priors=c(0.5,0.5)) {
## Purpose : Calculate local posterior
## Arguments
## ------------------------------------------------
## k,l: k and l must be undirected
## datX : external dataset
## datY : network data
## gInput : graph
## priors : prior for model A and B
## ------------------------------------------------ 
    p = nrow(gMat)
    seq_p =1:p
    
    stopifnot(ncol(datY)==p,nrow(datX)==nrow(datY))
    n = nrow(datY)
    q = ncol(datX)
    seq_q = 1:q
    
# find parents of k and l
    if (gMat[k,l]+gMat[l,k]!=2) stop("k - l must be undirected!")
    kP = seq_p[(gMat[,k]==1 & gMat[k,]==0)] # parents of k
    lP = seq_p[(gMat[,l]==1 & gMat[l,]==0)] # parents of l
    
# find external data corresponding to k and l
    kI = seq_q[B[k,]!=0]
    lI = seq_q[B[l,]!=0]
    
# conditioning set
    Mk = cbind(datY[,kP],datX[,kI])
    Ml = cbind(datY[,lP],datX[,lI])
    
    if (ncol(Mk) > 0 & ncol(Ml) >0) {
        fit = AB.posterior(datY[,k],datY[,l],priors.AB=priors,MA=Mk,MB=Ml)
    }else if (ncol(Mk) > 0 & ncol(Ml) == 0) {
        fit = AB.posterior(datY[,k],datY[,l],priors.AB=priors,MA=Mk,MB=NULL)    
    }else if (ncol(Mk) == 0 & ncol(Ml) > 0) {
        fit = AB.posterior(datY[,k],datY[,l],priors.AB=priors,MA=NULL,MB=Ml)
    }else {fit = AB.posterior(datY[,k],datY[,l],priors.AB=priors,MA=NULL,MB=NULL)}
    
    return(list(bf.M1 = fit$post.M1/fit$post.M2, post.M1 = fit$post.M1, post.M2 = fit$post.M2, loglik.M1 =fit$loglik.M1, loglik.M2=fit$loglik.M2)) # M1 : k -> l vs. M2: k <- l
}
