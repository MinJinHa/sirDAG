
AB.posterior <-
function(A,B,priors.AB = c(0.5,0.5),MA=NULL,MB=NULL) {
## Purpose : Calculate posteriors, P(M1|A,B,M) and P(M2|A,B,M)
##            M1 : A -> B vs. M2 : A <- B
## Arguments
## ------------------------------------------------
## A : length n expression data
## B : length n expression data
## priors.AB : prior for model A and B
## MA : row n parents data of A
## MB :  row n parents data of B
## ------------------------------------------------ 
    
    if(!is.numeric(A)){
        stop("A must be numeric vector\n")
    }
    if(!is.numeric(B)){
        stop("B must be numeric vector\n")
    }
    
    nn   = length(A)
    
    if(length(A)!=nn | length(B)!=nn ){
        stop("length A and B must be the same\n")
    }
    
    if (is.null(MA)) { lm1a = lm(A~1)
        lm2a = lm(A~B)
    }else { lm1a = lm(A~MA) 
        lm2a = lm(A~B + MA)}
    if (is.null(MB)) { lm1b = lm(B~A)
        lm2b = lm(B~1)
    }else { lm1b = lm(B~A + MB)
        lm2b = lm(B~MB)
    }
    sigma1a = sqrt(sum(lm1a$resid^2)/nn)
    sigma1b = sqrt(sum(lm1b$resid^2)/nn)
    sigma2a = sqrt(sum(lm2a$resid^2)/nn)
    sigma2b = sqrt(sum(lm2b$resid^2)/nn)
    
    intid1 = intersect(names(lm1a$resid),names(lm1b$resid))
    intid2 = intersect(names(lm2a$resid),names(lm2b$resid))
    lm1a$resid = lm1a$resid[match(intid1,names(lm1a$resid))]
    lm1b$resid = lm1b$resid[match(intid1,names(lm1b$resid))]
    lm2a$resid = lm2a$resid[match(intid2,names(lm2a$resid))]
    lm2b$resid = lm2b$resid[match(intid2,names(lm2b$resid))]

### M1: A~MA & B~A+MB / M2: B~MB & A~B+MA
    logp.M1 = sum(log(dnorm(x=lm1a$resid,mean=0,sd=sigma1a) *dnorm(x=lm1b$resid,mean=0,sd=sigma1b)))
    logp.M2 = sum(log(dnorm(x=lm2a$resid,mean=0,sd=sigma2a)* dnorm(x=lm2b$resid,mean=0,sd=sigma2b)))
    CC = max(logp.M1,logp.M2)
    p.M1 = exp(logp.M1-CC)
    p.M2 = exp(logp.M2-CC)
    
    post.M1 = p.M1 * priors.AB[1] / (p.M1*priors.AB[1] + p.M2*priors.AB[2])
    post.M2 = p.M2 * priors.AB[2] / (p.M1*priors.AB[1] + p.M2*priors.AB[2])
    
    return(list(post.M1=post.M1,post.M2 = post.M2,loglik.M1 = logp.M1, loglik.M2=logp.M2))
}

