BCDonG <-
function(start.edges,g,B,datX,datY,priors=c(0.5,0.5),bf.cut=1,verbose=F,num.gt=20,acyclic=T,NormalGamma=F,nu=NULL,delta=NULL,gg=NULL) {
    ## Purpose : Coordinate descent with posteriors
    ## Input
    ##  - varray      : starting vertices to direct
    ##  - g : a graph object for cpdag or skeleton
    ##  - B      : the relationship between interventional variables and gInput
    ##  - datX   : interventional dataset
    ##  - datY   : network data
    ##  - priors : priors for directions
    ##  - bf.cut : threshold for bayes factor
    ##  - vstructure : TRUE keep vstructure of gInput, FALSE allows extra vstructures
    ##  - acylic : TRUE with acyclic condition
    ##  - num.gt : number of random graphs
    ## NormalGamma : Use Normal Gamma priors
    ## nu, delta, gg are hyper parameters for Normal Gamma prior, b ~ N(0,gg\sigma^2(Z'Z)^-1 and 1/\sigma ~ gamma(nu/2,delta/2)
    p = nrow(g)
    seq_p =1:p
    
    stopifnot(ncol(datY)==p,nrow(datX)==nrow(datY))
    n = nrow(datY)
    q = ncol(datX)
    seq_q = 1:q
    
    if (!is.null(start.edges)) {start.edges = matrix(start.edges,ncol=2)}
    
    num.und = sum(g + t(g) ==2)
    if (num.und > 0 ){
        init.g = g
        if (!is.null(start.edges)) {
            unistartv = unique(start.edges[,1])
            init.v = sample(unistartv,1)
        } else {
            init.v= sample(1:p,1)
        }
            adj = init.v
            old.adj = numeric(0)
            while (length(adj) > 0) {
                for (k in adj) {
                    adjk = seq_p[(g[,k]==1 & g[k,]==1)]
                    if (length(adjk) > 0) {
                        for (l in adjk) {
                            #if (verbose) cat("no vstructure\n")
                            fit = one.BCDonG(k=k,l=l,gMat=g,B=B,datX=datX,datY=datY,NormalGamma=NormalGamma,nu=nu,delta=delta,gg=gg)
                            bf = fit$bf.M1
                            if (bf >= bf.cut) {
                                g[l,k] = 0
                                if (verbose) cat(k,"->",l,"by BF=",bf,"\n")
                                if (acyclic) {
                                    dg = g
                                    w = which(dg + t(dg)==2)
                                    dg[w] =0
                                    if(!isAcyclic(dg,method=1)) {
                                        g[l,k]=1
                                        if (verbose) cat(k,"-",l,"by acyclic constraints\n")
                                    }
                                }
                            }else if ((1/bf)>bf.cut) {
                                g[k,l] = 0
                                if (verbose) cat(l,"->",k,"by BF=",bf,"\n")
                                if (acyclic) {
                                    dg = g
                                    w = which(dg + t(dg)==2)
                                    dg[w] =0
                                    if(!isAcyclic(dg,method=1)) {
                                        g[k,l]=1
                                        if (verbose) cat(l,"-",k,"by acyclic constraints\n")
                                    }
                                }
                            }
                        }# for (l in adjk)
                    } #if (length(adjk) > 0)
                }#for (k in adj)
                old.adj = unique(c(old.adj,adj))
                up.adj = numeric(0)
                for (v in adj) {
                    up.adj = unique(c(up.adj, seq_p[g[,v] ==1 | g[v,] == 1]))
                }
                adj = setdiff(up.adj,old.adj)
            }
    }else {return(list(g = g))}
    return(list(g = g))
}

