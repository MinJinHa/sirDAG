
posterior2DAG <- function(gmat,prob,bf.cut,acyclic=T,verbose=T) {
    # =================================================
    # With posterior probability and skeleton, make DAG
    # Input:
    #   - g : graphNEL object for skeleton
    #   - prob : direction probability
    #   - bf.cut : cutoff for posteior
    # =================================================
    
    nn = nrow(prob)
    if (sum(gmat)>0 & nn>0) {
        p = ncol(gmat)
        
        pref1 = pref2 = numeric(0)
        for (i in 1:nrow(prob)) {
            if (prob[i,3]>prob[i,4]*bf.cut){
                pref1 = c(pref1,i)
            }else if (prob[i,4]>prob[i,3]*bf.cut){
                pref2 = c(pref2,i)
            }
        }
        
        address = rbind(prob[pref1,1:2],prob[pref2,2:1])
        posterior = c(prob[pref1,3],prob[pref2,4])
        o =  order(posterior,decreasing=T)
        posterior = posterior[o]
        address = address[o,,drop=F]
        
        address = unique(address)
        nn = nrow(address)
        
        if (nn>0) {
            for (i in 1:nn){
                if (verbose) {if (i%%100==0) print(i)}
                k = address[i,1]
                l = address[i,2]
                gmat[l,k]=0
                dmat = gmat
                dmat[(dmat==1 & t(dmat)==1)] = 0
                if (acyclic) {
                    if(!is.dag(igraph.from.graphNEL(as(dmat,"graphNEL")))) {
                        gmat[l,k]=1
                        if (verbose) cat(k,"-",l,"by acyclic constraints\n")
                    }
                }
            }
        }
        g = as(gmat,"graphNEL")
        }
    return(g)
}
