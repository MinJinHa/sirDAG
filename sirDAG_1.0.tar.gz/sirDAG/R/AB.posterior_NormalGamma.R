AB.posterior_NormalGamma <-
function(A,B,priors.AB = c(0.5,0.5),MA=NULL,MB=NULL,nu,delta,g) {
## Purpose : Calculate posteriors, P(M1|A,B,M) and P(M2|A,B,M)
##            M1 : A -> B vs. M2 : A <- B
##          when b ~ N(0,g\sigma^2(Z'Z)^-1 and 1/\sigma ~ gamma(nu/2,delta/2)
## Arguments
## ------------------------------------------------
## A : length n expression data (standardized)
## B : length n expression data (standardized)
## priors.AB : prior for model A and B (standardized)
## MA : row n parents data of A (standardized)
## MB :  row n parents data of B
## nu :
## ------------------------------------------------ 
    
    if(!is.numeric(A)){
        stop("A must be numeric vector\n")
    }
    if(!is.numeric(B)){
        stop("B must be numeric vector\n")
    }
    
    nn   = length(A)
    I = diag(nn)
    if(length(A)!=nn | length(B)!=nn ){
        stop("length A and B must be the same\n")
    }
    
    func_locallPost <- function(n,nu,delta,g,p,SSR) {
        (-n/2)*log(pi) + log(gamma((nu+n)/2)) - log(gamma(nu/2)) + (-p/2)*log(1+g) + (nu/2) * log(delta) -((nu+n)/2)* log(SSR+delta)
    }
    
    ### M1 (A->B): A~MA & B~A+MB VS. M2 (B->A): B~MB & A~B+MA
    ### M1a: A~MA, M2a: A~B+MA, M1b: B~A+MB, M2b: B~MB
    if (is.null(MA)) {
        SSR.M1a = sum(A^2) # A'A
        
        IH = I-(g/(g+1)) * (1/sum(B^2)) * tcrossprod(B)
        SSR.M2a = crossprod(A,IH%*%A)
        
        lpost.M1a = func_locallPost(n=nn,nu=nu,delta=delta,g=g,p=0,SSR=SSR.M1a)
        lpost.M2a = func_locallPost(n=nn,nu=nu,delta=delta,g=g,p=1,SSR=SSR.M2a)
    }else {
        pMA = ncol(MA)
        IH = I - (g/(g+1)) * tcrossprod(svd(MA)$u)
        SSR.M1a = crossprod(A,IH%*%A)
        
        IH = I - (g/(g+1)) * tcrossprod(svd(cbind(MA,B))$u)
        SSR.M2a = crossprod(A,IH%*%A)
        
        lpost.M1a = func_locallPost(n=nn,nu=nu,delta=delta,g=g,p=pMA,SSR=SSR.M1a)
        lpost.M2a = func_locallPost(n=nn,nu=nu,delta=delta,g=g,p=pMA+1,SSR=SSR.M2a)
    }
    
    if (is.null(MB)) {
        IH = I-(g/(g+1)) * (1/sum(A^2)) * tcrossprod(A)
        SSR.M1b = crossprod(B,IH%*%B)

        SSR.M2b = sum(B^2)
        
        lpost.M1b = func_locallPost(n=nn,nu=nu,delta=delta,g=g,p=1,SSR=SSR.M1b)
        lpost.M2b = func_locallPost(n=nn,nu=nu,delta=delta,g=g,p=0,SSR=SSR.M2b)
    }else {
        pMB = ncol(MB)
        IH = I - (g/(g+1)) * tcrossprod(svd(cbind(MB,A))$u)
        SSR.M1b = crossprod(B,IH%*%B)
        
        IH = I - (g/(g+1)) * tcrossprod(svd(MB)$u)
        SSR.M2b = crossprod(B,IH%*%B)
        
        lpost.M1b = func_locallPost(n=nn,nu=nu,delta=delta,g=g,p=pMB+1,SSR=SSR.M1b)
        lpost.M2b = func_locallPost(n=nn,nu=nu,delta=delta,g=g,p=pMB,SSR=SSR.M2b)
    }
    
    ### M1: A~MA & B~A+MB / M2: B~MB & A~B+MA
    logp.M1 = sum(lpost.M1a + lpost.M1b) # marginal Likelihood
    logp.M2 = sum(lpost.M2a + lpost.M2b) # Marginal Likelihood 
    CC = max(logp.M1,logp.M2)
    p.M1 = exp(logp.M1-CC)
    p.M2 = exp(logp.M2-CC)

    post.M1 = p.M1 * priors.AB[1] / (p.M1*priors.AB[1] + p.M2*priors.AB[2])
    post.M2 = p.M2 * priors.AB[2] / (p.M1*priors.AB[1] + p.M2*priors.AB[2])

    return(list(post.M1=post.M1,post.M2 = post.M2,loglik.M1 = logp.M1, loglik.M2=logp.M2))
}

