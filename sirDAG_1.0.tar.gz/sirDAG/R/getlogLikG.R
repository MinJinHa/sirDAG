getlogLikG <-
function(g,B,datX,datY) {
## --------------------------------------------------------
## Purpose : obtain likelihood
##   Input : 
##       - g : a matrix which is a graph 
##       - B : a relationship between g and X
##       - datX : data for interventional variables
##       - datY : data for observational variables
## --------------------------------------------------------
    if (any((g + t(g)) == 2)) stop("all edges in g should be directed")
    p = nrow(g)
    seq_p = 1:p
    
    stopifnot(ncol(datY)==p,nrow(datX)==nrow(datY))
    n = nrow(datY)
    q = ncol(datX)
    seq_q = 1:q
    
    candv = unique(c(which(g==1,arr.ind=T)))
    lLik = 0
    if (any(candv)) {
        for (v in candv) {
            pav = seq_p[(g[,v]==1 & g[v,]==0)]
            vI = seq_q[B[v,]!=0]
            M = cbind(datY[,pav],datX[,vI])
            if (ncol(M) > 0) {
                lmfit = lm(datY[,v]~M)
            }else { lmfit = lm(datY[,v]~1)}
            sigma = sqrt(sum(lmfit$resid^2)/n)
            lLik = lLik + sum(log(dnorm(x=lmfit$resid,mean=0,sd=sigma)))
        }
    }
    return(lLik)
}
