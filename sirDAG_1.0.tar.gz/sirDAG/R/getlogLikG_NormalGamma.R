getlogLikG_NormalGamma <-
function(g,B,datX,datY,nu,delta,gg) {
## --------------------------------------------------------
## Purpose : obtain likelihood
##   Input : 
##       - g : a matrix which is a graph 
##       - B : a relationship between g and X
##       - datX : data for interventional variables
##       - datY : data for observational variables
## --------------------------------------------------------
#if (any((g + t(g)) == 2)) stop("all edges in g should be directed")
    p = nrow(g)
    seq_p = 1:p
    
    stopifnot(ncol(datY)==p,nrow(datX)==nrow(datY))
    n = nrow(datY)
    q = ncol(datX)
    seq_q = 1:q
    I = diag(n)


    func_locallPost <- function(n,nu,delta,g,p,SSR) {
        (-n/2)*log(pi) + log(gamma((nu+n)/2)) - log(gamma(nu/2)) + (-p/2)*log(1+g) + (nu/2) * log(delta) -((nu+n)/2)* log(SSR+delta)
    }


    lLik = 0
    for (v in 1:p) {
        pav = seq_p[(g[,v]==1 & g[v,]==0)]
        vI = seq_q[B[v,]!=0]
        M = cbind(datY[,pav],datX[,vI])
        pM = ncol(M)
        y = datY[,v]
        if (ncol(M) > 0) {
            IH = I - (gg/(gg+1)) * tcrossprod(svd(M)$u)
            SSR = crossprod(y,IH%*%y)
            vlLik = func_locallPost(n=n,nu=nu,delta=delta,g=gg,p=pM,SSR=SSR)
        }else {
            SSR = sum(y^2) # A'A
            vlLik = func_locallPost(n=n,nu=nu,delta=delta,g=gg,p=0,SSR=SSR)
        }
        #print(vlLik)
        lLik = lLik + vlLik
    }
    
    return(lLik)
}
