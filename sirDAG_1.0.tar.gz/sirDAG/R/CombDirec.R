CombDirec <-
function(p,V) { 
## This function is to detect all possible subsets among p 
## V is a vector including the samples 
## V = 1:2^p gives all possible combinations
    
    set = matrix(0,length(V),p)
    for (i in (V-1)) {
        x = substring(paste(as.integer(intToBits(i)), collapse=""),0,p)
        set[i,] = as.numeric(substring(x, seq(1,nchar(x),1), seq(1,nchar(x),1)))
    }
    return(set)
}
