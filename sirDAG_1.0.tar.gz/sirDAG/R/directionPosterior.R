directionPosterior <-
function(gInput,B,datX,datY,exhaustive.cut=10,no.T=2^10,bf.cut1=1,bf.cut2=1.2, verbose=F,acyclic=T) {
## Purpose : Calculate direction probabilities for each undirected edges in gInput (using modules)
## Input 
##  - varray      : starting vertices to direct
##  - gInput : a graph object for cpdag or skeleton
##  - B      : the relationship between interventional variables and gInput
##  - datX   : interventional dataset
##  - datY   : network data
##  - no.T  : number of random graphs
    G = as(gInput,"matrix")
    p = nrow(G)
    seq_p =1:p
    colnames(G) = rownames(G) =1:p
    
    stopifnot(ncol(datY)==p,nrow(datX)==nrow(datY))
    n = nrow(datY)
    q = ncol(datX)
    seq_q = 1:q
    
    udG = G+t(G)
    und.ind = which(udG==2,arr.ind=T) # undirected edges
    
    if (nrow(und.ind)>0) {
# calculate connected components
        clfit = clusters(igraph.from.graphNEL(gInput))
        if (verbose) cat("sizes of clusters : ",table(clfit$membership),"\n")
        cls = unique(clfit$membership)
        Edges.posterior = numeric(0)
        cat("# of clusters=",length(cls),"\n")
        for (ll in 1:length(cls)){
            cl = cls[ll]
            clid = which(clfit$membership ==cl) 
            cl.p = length(clid)
            if (cl.p > 1) {
# Input graph
                clg = G[clid,clid]
                colnames(clg) = rownames(clg) = 1:cl.p
                cl.und.ind = matrix(which(clg ==1 & t(clg) ==1,arr.ind=T),ncol=2)
# Input data
                cl.datY = datY[,clid]
                clB = B[clid,]
                riG = sampleStartEdges(g=clg,B=clB,datX=datX,datY=cl.datY,exhaustive.cut=exhaustive.cut,no.T=no.T,acyclic=acyclic)
                if (riG$OK) { ## if there is at least one starting edge 
                    no.T = nrow(riG$combn.direc)
                    ind= riG$start.edges
                    
                    lLik = numeric(0)
                    direc.und = numeric(0) 
                    cat("cluster=",ll,", # of Gt = ",no.T,date(),"\n")
                    for (tt in 1:no.T) {
                        if (tt %% 50 == 0) {cat("tt=", tt," ")}
                        Gt = clg
                        ind2 = cbind(ind[,2],ind[,1])
                        ind.tmp = rbind(ind[riG$combn.direc[tt,]==0,],ind2[riG$combn.direc[tt,]==1,])
                        Gt[ind.tmp] =0
                        fit = BCDonG(start.edges=riG$start.edges,g=Gt,B=clB,datX=datX,datY=cl.datY,bf.cut=bf.cut1,verbose=FALSE,acyclic=acyclic)
                        if (fit$OK) {
                            w.g2 = which(fit$g + t(fit$g) == 2)
                            if (length(w.g2)>0) {
                                g = fit$g
                                g[w.g2] =0
                                lLik = c(lLik,getlogLikG(g=g,B=clB,datX=datX,datY=cl.datY))
                            }else { lLik = c(lLik,getlogLikG(g=fit$g,B=clB,datX=datX,datY=cl.datY))}
                            dgg = as(fit$g,"matrix")
                            dgg[dgg==1 & t(dgg)==1] =0
                            direc.und = cbind(direc.und,dgg[cl.und.ind])
                        }
                    }  
# get posterior for each undirected edges
                    Cfac = max(lLik)                    
                    posterior = rowSums(t(t(direc.und) * exp(lLik - Cfac))) /  sum(exp(lLik - Cfac))
                    
                    Edges = matrix(nrow = length(posterior)/2,ncol=4)
                    Edges[,1:2] = unique(t(apply(cl.und.ind,1,sort)))
                    colnames(Edges) = c("k","l","k->l","l->k")
                    for (i in 1:nrow(Edges)) {
e = Edges[i,1:2]
w = which(sapply(1:nrow(cl.und.ind),function(v) all(cl.und.ind[v,]==e)))
Edges[i,3] = posterior[w]
e = e[c(2,1)]
w = which(sapply(1:nrow(cl.und.ind),function(v) all(cl.und.ind[v,]==e)))
Edges[i,4] =posterior[w]
                    } 
                    Edges[,1] = clid[Edges[,1]]
                    Edges[,2] = clid[Edges[,2]]
                    Edges.posterior = rbind(Edges.posterior,Edges)
                }    ###if (riG$OK) 
            } ###if (cl.p > 1)
        }###for (ll in 1:length(cls))        
        return(list(posterior = Edges.posterior,g=posterior2DAG(gmat=G,prob=Edges.posterior,bf.cut=bf.cut2, acyclic=acyclic,verbose=verbose),OK=TRUE ))
    }else {return(list(posterior=NULL,g=gInput,OK=FALSE))}##########if if (nrow(und.ind)>0) { ===> no undirected edges
}
