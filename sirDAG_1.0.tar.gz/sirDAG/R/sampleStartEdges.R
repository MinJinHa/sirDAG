sampleStartEdges <- function(g,B,datX,datY,exhaustive.cut=10,no.T=2^11,tol=10,acyclic=T) {
    ## ---------------------------------------------------------------
    ## Purpose : sample starting edge directions with at least one eQTL
    ##           with only acyclic restriction
    ##       g : matrix
    ##       B : eQTL adjacency matrix
    ##       datX : data for B
    ##       datY : data for G
    ##       exhaustive.cut : The number of starting edges
    ##                        greater than this value will do sampling with posteriors
    ##       no.T: if sampled, how many?
    ##       tol : # of replications for sampling directions
    ## ----------------------------------------------------------------
    
    p = nrow(g)
    seq_p = 1:p
    stopifnot(nrow(B)==p)
    q = ncol(B)
    
    if(sum(g)>0 & q>0) {
        # get starting edges
        In = seq_p[rowSums(B)!=0]
        ind = numeric(0)
        for (v in In) {
            karr = seq_p[g[,v] ==1 & g[v,] == 1]
            if (length(karr) >0) {
                ind = rbind(ind,cbind(rep(v,length(karr)),karr))
            }
        }
        ind = matrix(ind,ncol=2)
        ind = unique(t(apply(ind,1,sort))) # unique rows
        n.start = nrow(ind)
        subv = unique(c(ind))
        if (n.start>0) { # if  starting edge
            if (n.start<=exhaustive.cut) {
                edgedirec = CombDirec(n.start,1:2^n.start)
                no.uniT = nrow(edgedirec)
                okT = rep(0,no.uniT)
                for (tt in 1:no.uniT){
                    onedirec = edgedirec[tt,]
                    ind2= cbind(ind[,2],ind[,1])
                    ind.tmp = rbind(ind[onedirec==0,],ind2[onedirec==1,])
                    subg = g
                    subg[ind.tmp] = 0
                    subg = subg[subv,subv]
                    subg[subg==1 & t(subg)==1] = 0
                    if ( is.dag(igraph.from.graphNEL(as(subg,"graphNEL"))) == TRUE) {   okT[tt] = 1 }
                }
                edgedirec = edgedirec[okT==1,]
                edgedirec = matrix(unique(edgedirec),ncol=n.start)
                colnames(ind) = c("k","l")
                return(list(start.edges=ind,combn.direc=edgedirec,OK=TRUE))
            }else { # sample by posterior
                postkl =rep(0,n.start)
                for (i in 1:n.start) {
                    k = ind[i,1]
                    l = ind[i,2]
                    postkl[i] = one.BCDonG(k=k,l=l,gMat=g,B=B,datX=datX,datY=datY)$post.M1
                }
                edgedirec = numeric(0)
                noarr.T = 0
                rep.T = 0
                while (noarr.T < no.T & rep.T < tol) {
                    rep.T = rep.T+1
                    no.sample = no.T - noarr.T
                    edgedirecP = matrix(sapply(1:n.start,function(i) rbinom(n=no.sample,size=1,prob=postkl[i])[sample(1:no.sample)]),ncol=n.start)
                    edgedirecP = unique(matrix(edgedirecP,ncol=n.start))
                    if (acyclic) {
                        no.uniT = nrow(edgedirecP)
                        okT = rep(0,no.uniT)
                        for (tt in 1:no.uniT){
                            onedirec = edgedirecP[tt,]
                            ind2= cbind(ind[,2],ind[,1])
                            ind.tmp = rbind(ind[onedirec==0,],ind2[onedirec==1,])
                            subg = g
                            subg[ind.tmp] = 0
                            subg = subg[subv,subv]
                            subg[subg==1 & t(subg)==1] = 0
                            if ( is.dag(igraph.from.graphNEL(as(subg,"graphNEL"))) == TRUE) {   okT[tt] = 1 }
                        }
                        edgedirecP = edgedirecP[okT==1,]
                        edgedirecP = unique(matrix(edgedirecP,ncol=n.start))
                    }
                    if (!is.null(nrow(edgedirecP))) {
                        edgedirec = rbind(edgedirec,edgedirecP)
                        edgedirec = unique(matrix(edgedirec,ncol=n.start))
                        noarr.T = nrow(edgedirec)
                    }
                    # cat(noarr.T,"\n")
                }
                colnames(ind) = c("k","l")
                return(list(start.edges=ind,combn.direc=edgedirec,OK=TRUE))
            } ##(n.start<=exhaustive.cut)
        }else {return(list(start.edges=NULL,combn.direc=NULL,OK=FALSE))}
    }else {return(list(start.edges=NULL,combn.direc=NULL,OK=FALSE))}
}

