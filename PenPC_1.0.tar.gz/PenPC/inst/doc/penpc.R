### R code from vignette source 'penpc.Rnw'
### Encoding: UTF-8

###################################################
### code chunk number 1: PenPC
###################################################
options(keep.source = TRUE, width = 60)
PenPC <- packageDescription("PenPC")


###################################################
### code chunk number 2: penpc.Rnw:30-31
###################################################
library(PenPC)


###################################################
### code chunk number 3: penpc.Rnw:38-42
###################################################
p = 100 
n = 30 
e = 1 
simul=simul.BA(p,e,n)


###################################################
### code chunk number 4: penpc.Rnw:46-49
###################################################
dim(simul$A)
dim(simul$X)
simul$G


###################################################
### code chunk number 5: penpc.Rnw:54-57
###################################################
dat = simul$X
coeff = ne.PEN(dat=dat,nlambda=100,ntau=10,V=1:p,order=TRUE)
sum(coeff!=0)


###################################################
### code chunk number 6: penpc.Rnw:61-62
###################################################
coeff.sel= ne.PEN(dat=dat,nlambda=100,ntau=10,V=c(1,2,3),order=TRUE)


###################################################
### code chunk number 7: penpc.Rnw:65-67
###################################################
edgeWeights = matrix(0,p,p)
edgeWeights[coeff!=0|t(coeff)!=0] =1


###################################################
### code chunk number 8: penpc.Rnw:70-76
###################################################
alpha = 0.01
indepTest = gaussCItest
suffStat  = list(C = cor(dat), n = n) 
fit.penpc  = skeletonPENstable(suffStat, indepTest, as.integer(p), alpha, 
edgeWeights=edgeWeights, verbose=F)
fit.penpc@graph


